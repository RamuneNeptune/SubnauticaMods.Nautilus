﻿

namespace Ramune.$safeprojectname$
{
    [Menu("$safeprojectname$")]
    public class Config : ConfigFile
    {

    }
}